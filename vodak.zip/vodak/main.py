from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__, static_url_path='/static', static_folder='static', template_folder='templates')

registrace_data = []

@app.route('/', methods=['GET'])
def index():
    return render_template('prvni_stranka.html', ucastnici=registrace_data), 200

@app.route('/druha_stranka', methods=['GET', 'POST'])
def druha_stranka():
    return render_template('druha_stranka.html', zprava="Tajná zpráva.."), 200

@app.route('/registrace', methods=['GET', 'POST'])
def registrace():
    if request.method == 'POST':
        nick = request.form.get('nick')
        je_plavec = request.form.get('je_plavec')
        kanoe_kamarad = request.form.get('kanoe_kamarad')

        if je_plavec != '1':
            return "Chyba: Musíte umět plavat", 400

        if not (2 <= len(nick) <= 20) or not nick.isalnum():
            return "Chyba: Přezdívka musí mít 2 až 20 znaků a obsahovat pouze čísla a písmena bez mezer", 400

        if not (2 <= len(kanoe_kamarad) <= 20) or not kanoe_kamarad.isalnum():
            return "Chyba: Kanoe kamarád musí mít 2 až 20 znaků a obsahovat pouze čísla a písmena bez mezer", 400

        registrace_data.append({
            'nick': nick,
            'je_plavec': je_plavec,
            'kanoe_kamarad': kanoe_kamarad
        })

        return redirect(url_for('index'))

    return render_template('registrace.html'), 200




if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
